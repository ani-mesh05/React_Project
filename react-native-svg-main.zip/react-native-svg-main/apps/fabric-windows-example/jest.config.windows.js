const config = {};

module.exports = require('@rnx-kit/jest-preset')('windows', config);
