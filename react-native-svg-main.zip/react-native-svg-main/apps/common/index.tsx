import App from './example';

export default App;
