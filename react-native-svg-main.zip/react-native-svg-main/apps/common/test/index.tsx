/* eslint-disable no-unused-vars */
import React from 'react';

import ColorTest from './ColorTest';
import PointerEventsBoxNone from './PointerEventsBoxNone';
import MountUnmount from './MountUnmount';
import Test1318 from './Test1318';
import Test1374 from './Test1374';
import Test1442 from './Test1442';
import Test1451 from './Test1451';
import Test1718 from './Test1718';
import Test1790 from './Test1790';
import Test1813 from './Test1813';
import Test1845 from './Test1845';
import Test1986 from './Test1986';
import Test2071 from './Test2071';
import Test2080 from './Test2080';
import Test2086 from './Test2086';
import Test2089 from './Test2089';
import Test2142 from './Test2142';
import Test2148 from './Test2148';
import Test2196 from './Test2196';
import Test2248 from './Test2248';
import Test2266 from './Test2266';
import Test2276 from './Test2276';
import Test2327 from './Test2327';
import Test2233 from './Test2233';
import Test2363 from './Test2363';
import Test2366 from './Test2366';
import Test2380 from './Test2380';
import Test2397 from './Test2397';
import Test2403 from './Test2403';
import Test2407 from './Test2407';
import Test2417 from './Test2417';
import Test2455 from './Test2455';
import Test2471 from './Test2471';
import Test2520 from './Test2520';

export default function App() {
  return <ColorTest />;
}
