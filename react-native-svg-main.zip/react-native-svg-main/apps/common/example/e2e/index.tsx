import {icon} from './icon';
import {TestingView} from './TestingView';

const component = TestingView;
export {component, icon};
