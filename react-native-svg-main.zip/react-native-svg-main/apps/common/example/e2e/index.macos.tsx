import React from 'react';
import {icon} from './icon';

const component = () => <React.Fragment key="E2E" />;
export {component, icon};
