# SVG Example app

Showcase of what this library can do 🚀
