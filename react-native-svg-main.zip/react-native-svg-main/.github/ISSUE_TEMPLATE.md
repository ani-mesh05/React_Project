# No Template

👉 Please follow one of the issue templates provided by the repo - if you are seeing this message, it means you haven't.

If you don't follow the issue template, we may immediately close it.
