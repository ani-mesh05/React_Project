typedef CF_ENUM(int32_t, RNSVGMaskType) {
  kRNSVGMaskTypeLuminance,
  kRNSVGMaskTypeAlpha
};
