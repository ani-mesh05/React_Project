#import "RNSVGFilterPrimitiveManager.h"

@interface RNSVGFeBlendManager : RNSVGFilterPrimitiveManager

@end
