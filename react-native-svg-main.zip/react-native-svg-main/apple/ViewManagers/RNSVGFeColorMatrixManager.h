#import "RNSVGFilterPrimitiveManager.h"

@interface RNSVGFeColorMatrixManager : RNSVGFilterPrimitiveManager

@end
