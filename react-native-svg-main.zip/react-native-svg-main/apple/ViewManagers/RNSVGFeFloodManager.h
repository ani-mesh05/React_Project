#import "RNSVGFilterPrimitiveManager.h"

@interface RNSVGFeFloodManager : RNSVGFilterPrimitiveManager

@end
