#import "RNSVGNodeManager.h"

@interface RNSVGFilterManager : RNSVGNodeManager

@end
