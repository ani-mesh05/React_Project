#import "RNSVGFilterPrimitiveManager.h"

@interface RNSVGFeMergeManager : RNSVGFilterPrimitiveManager

@end
