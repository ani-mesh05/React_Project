#import "RNSVGFilterPrimitiveManager.h"

@interface RNSVGFeOffsetManager : RNSVGFilterPrimitiveManager

@end
