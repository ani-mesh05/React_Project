#import "RNSVGFilterPrimitiveManager.h"

@interface RNSVGFeCompositeManager : RNSVGFilterPrimitiveManager

@end
