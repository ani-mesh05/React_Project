#import "RNSVGNodeManager.h"

@interface RNSVGFilterPrimitiveManager : RNSVGNodeManager

@end
