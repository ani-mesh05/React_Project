#import "RNSVGFilterPrimitiveManager.h"

@interface RNSVGFeGaussianBlurManager : RNSVGFilterPrimitiveManager

@end
