#import "RNSVGCustomFilter.h"

@interface RNSVGCompositeXor : RNSVGCustomFilter {
  CIImage *inputImage2;
}

@end
