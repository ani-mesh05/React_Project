#import "RNSVGFilterPrimitive.h"

@interface RNSVGFeMerge : RNSVGFilterPrimitive

@property (nonatomic, copy) NSArray<NSString *> *nodes;

@end
